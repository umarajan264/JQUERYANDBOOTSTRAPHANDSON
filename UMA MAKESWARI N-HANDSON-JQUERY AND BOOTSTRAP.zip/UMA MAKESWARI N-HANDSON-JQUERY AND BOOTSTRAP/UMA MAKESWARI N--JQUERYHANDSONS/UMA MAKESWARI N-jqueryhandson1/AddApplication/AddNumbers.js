function add_two_number()
{
   $("#display_msg").show();
   if($("#num1").val()=="" || $("#num2").val()=="")
   {
      $("#display_msg").html("<font color='red'>Please,Enter The Values.</font>");
   }
   else
  {
    var answer=parseInt($("#num1").val()) + parseInt($("#num2").val())
       
    $("#display_msg").html("<font color='green'><b>"+answer+"</b></font>");
 $("#num3").val(answer);
 
   }
}
